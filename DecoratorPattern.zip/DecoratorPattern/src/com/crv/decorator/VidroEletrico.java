package com.crv.decorator;
import com.crv.veiculo.Veiculo;

public class VidroEletrico extends AcessorioDecorator {

	Veiculo veiculo;
	
	public VidroEletrico(Veiculo beverage) {
		this.veiculo = beverage;
	}
	
	@Override
	public String getDescricao() {
		return veiculo.getDescricao() + ", Vidro Elétrico";
	}

	@Override
	public double custo() {
		return 2500 + veiculo.custo();
	}
	
}
