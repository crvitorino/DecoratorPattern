package com.crv.decorator;
import com.crv.veiculo.Veiculo;

public abstract class AcessorioDecorator extends Veiculo {

	public abstract String getDescricao(); 
	
}
