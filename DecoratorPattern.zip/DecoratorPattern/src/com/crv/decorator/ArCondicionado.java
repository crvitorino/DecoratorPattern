package com.crv.decorator;
import com.crv.veiculo.Veiculo;

public class ArCondicionado extends AcessorioDecorator {

	Veiculo veiculo;
	
	public ArCondicionado(Veiculo veiculo) {
		this.veiculo = veiculo;
	}
	
	@Override
	public String getDescricao() {
		return veiculo.getDescricao() + ", Ar Condicionado";
	}

	@Override
	public double custo() {
		return 5000 + veiculo.custo();
	}
	
}
