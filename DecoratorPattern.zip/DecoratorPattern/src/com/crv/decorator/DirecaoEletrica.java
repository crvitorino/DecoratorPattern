package com.crv.decorator;
import com.crv.veiculo.Veiculo;

public class DirecaoEletrica extends AcessorioDecorator {

	Veiculo veiculo;
	
	public DirecaoEletrica(Veiculo veiculo) {
		this.veiculo = veiculo;
	}
	
	@Override
	public String getDescricao() {
		return veiculo.getDescricao() + ", Direção Elétrica";
	}

	@Override
	public double custo() {
		return 6000 + veiculo.custo();
	}
	
}
