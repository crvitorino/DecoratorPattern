package com.crv.decorator;
import com.crv.veiculo.Veiculo;

public class AirBag extends AcessorioDecorator {

	Veiculo veiculo;
	
	public AirBag(Veiculo beverage) {
		this.veiculo = beverage;
	}
	
	@Override
	public String getDescricao() {
		return veiculo.getDescricao() + ", Air Bag";
	}

	@Override
	public double custo() {
		return 2200 + veiculo.custo();
	}
	
}
