package com.crv;

import com.crv.decorator.AirBag;
import com.crv.decorator.ArCondicionado;
import com.crv.decorator.DirecaoEletrica;
import com.crv.decorator.VidroEletrico;
import com.crv.veiculo.Cruze;
import com.crv.veiculo.Frontier;
import com.crv.veiculo.Toro;
import com.crv.veiculo.Veiculo;

public class RevendaVeiculo {

	public static void main(String[] args) {

		Veiculo veiculo = new Toro();
		
		System.out.println();
		System.out.println(veiculo.getDescricao() 
				+ " R$ " + veiculo.custo());
		
		Veiculo veiculo2 = new Cruze();
		veiculo2 = new DirecaoEletrica(veiculo2);
		veiculo2 = new AirBag(veiculo2);
		veiculo2 = new AirBag(veiculo2);
		veiculo2 = new VidroEletrico(veiculo2);
		
		System.out.println(veiculo2.getDescricao() 
				+ " R$ " + veiculo2.custo());
		
		Veiculo veiculo3 = new Frontier();
		veiculo3 = new ArCondicionado(veiculo3);
		veiculo3 = new DirecaoEletrica(veiculo3);
		veiculo3 = new VidroEletrico(veiculo3);
		
		System.out.println(veiculo3.getDescricao() 
				+ " R$ " + veiculo3.custo());
		
		System.out.println();
		System.out.println("                      --- Preços e informações meramente ilustrativos ---");
		System.out.println("****************************************************************************************");
		System.out.println("As informações apresentadas aqui tem apenas caráter didático.");
		System.out.println("Para dados oficiais dos veículos, consulte o site dos respectivos fabricantes.");
		System.out.println("****************************************************************************************");
		
	}

}
