package com.crv.veiculo;

public class Toro extends Veiculo {

	public Toro() {
		descricao = "Fiat Toro";
	}

	@Override
	public double custo() {
		return 89000;
	}
	
}
