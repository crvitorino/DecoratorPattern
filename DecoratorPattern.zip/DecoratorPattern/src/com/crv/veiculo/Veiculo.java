package com.crv.veiculo;

public abstract class Veiculo {
	
	String descricao = "Veículo Desconhecido";
	
	public String getDescricao() {
		return descricao;
	}
	
	public abstract double custo();

}
