package com.crv.veiculo;

public class NewCivic extends Veiculo {

	public NewCivic() {
		descricao = "Honda Civic";
	}
	
	@Override
	public double custo() {
		return 118000;
	}

}
