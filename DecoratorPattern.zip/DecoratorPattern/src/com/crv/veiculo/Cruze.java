package com.crv.veiculo;

public class Cruze extends Veiculo {

	public Cruze() {
		descricao = "Chevrolet Cruze";
	}
	
	@Override
	public double custo() {
		return 87000;
	}

}
