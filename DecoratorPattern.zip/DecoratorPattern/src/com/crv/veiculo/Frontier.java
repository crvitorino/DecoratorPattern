package com.crv.veiculo;

public class Frontier extends Veiculo {

	public Frontier() {
		descricao = "Nissan Frontier";
	}
	
	@Override
	public double custo() {
		return 149900;
	}

}
